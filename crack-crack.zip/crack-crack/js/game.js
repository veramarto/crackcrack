const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 450,
    backgroundColor: '#CFEBFF',

    physics: {
        default: 'arcade',
        arcade: {
            gravity: { y: 700 },
            debug: false
        }
    },

    scene: {
        preload: preload,
        create: create,
        update: update
    }
};

const game = new Phaser.Game(config);

let player;
let cursors;
let platformList = [];
let coffees;
let knives;
let score = 0;
let scoreText;

function preload() {
    this.load.spritesheet('eggou', 'assets/eggou_spritesheet.png', {
        frameWidth: 64,
        frameHeight: 64
    });
}

function create() {
    score = 0;
    platformList = [];

    createPlatform(this, 400, 430, 800, 40);
    createPlatform(this, 220, 330, 220, 24);
    createPlatform(this, 500, 250, 220, 24);
    createPlatform(this, 260, 170, 180, 24);

player = this.physics.add.sprite(80, 380, 'eggou');

player.setScale(1);
player.body.setSize(28, 44);
player.body.setOffset(18, 18);
player.body.setCollideWorldBounds(false);
player.body.setBounce(0);

this.physics.add.collider(player, platformList);

this.anims.create({
    key: 'idle',
    frames: this.anims.generateFrameNumbers('eggou', {
        start: 0,
        end: 3
    }),
    frameRate: 4,
    repeat: -1
});

this.anims.create({
    key: 'walk',
    frames: this.anims.generateFrameNumbers('eggou', {
        start: 4,
        end: 7
    }),
    frameRate: 8,
    repeat: -1
});

this.anims.create({
    key: 'jump',
    frames: this.anims.generateFrameNumbers('eggou', {
        start: 8,
        end: 9
    }),
    frameRate: 6,
    repeat: -1
});

this.anims.create({
    key: 'death',
    frames: this.anims.generateFrameNumbers('eggou', {
        start: 10,
        end: 13
    }),
    frameRate: 8,
    repeat: 0
});

    cursors = this.input.keyboard.createCursorKeys();

    coffees = this.physics.add.staticGroup();

    createCoffee(this, 220, 290);
    createCoffee(this, 500, 210);
    createCoffee(this, 260, 130);
    createCoffee(this, 690, 390);
    createCoffee(this, 120, 390);

    this.physics.add.overlap(
        player,
        coffees,
        collectCoffee,
        null,
        this
    );

    knives = this.physics.add.group({
        allowGravity: false
    });

    createKnife(this, 620, 380, 120, 720);

    this.physics.add.overlap(
        player,
        knives,
        hitKnife,
        null,
        this
    );

    scoreText = this.add.text(16, 16, 'Punts: 0', {
        fontSize: '24px',
        color: '#402105'
    });
}

function update() {
    if (cursors.left.isDown) {
    player.body.setVelocityX(-220);
    player.setFlipX(true);

    if (player.body.touching.down) {
        player.anims.play('walk', true);
    }

} else if (cursors.right.isDown) {
    player.body.setVelocityX(220);
    player.setFlipX(false);

    if (player.body.touching.down) {
        player.anims.play('walk', true);
    }

} else {
    player.body.setVelocityX(0);

    if (player.body.touching.down) {
        player.anims.play('idle', true);
    }
}

if (cursors.up.isDown && player.body.touching.down) {
    player.body.setVelocityY(-430);
}

if (!player.body.touching.down) {
    player.anims.play('jump', true);
}

const knifeArray = knives.getChildren();

for (let i = 0; i < knifeArray.length; i++) {
    const knife = knifeArray[i];

    knife.x += knife.speed;

    if (knife.x <= knife.minX || knife.x >= knife.maxX) {
        knife.speed *= -1;
    }
}

    if (player.y > 520) {
        this.scene.restart();
    }
}

function createPlatform(scene, x, y, width, height) {
    const platform = scene.add.rectangle(x, y, width, height, 0x402105);
    scene.physics.add.existing(platform, true);

    scene.add.rectangle(x, y - height / 2, width, 4, 0xFFE448);

    platformList.push(platform);
}

function createCoffee(scene, x, y) {
    const coffee = scene.add.circle(x, y, 10, 0x6F4E37);
    scene.physics.add.existing(coffee, true);
    coffees.add(coffee);
}

function createKnife(scene, x, y, minX, maxX) {
    const knife = scene.add.rectangle(x, y, 50, 10, 0xCCCCCC);
    scene.physics.add.existing(knife);

    knife.body.allowGravity = false;
    knife.speed = -2;
    knife.body.setImmovable(true);

    knife.minX = minX;
    knife.maxX = maxX;

    knives.add(knife);
}

function collectCoffee(player, coffee) {
    coffee.destroy();

    score += 10;
    scoreText.setText('Punts: ' + score);

    if (score >= 50) {
        alert("HAS ESCAPAT DE LA CUINA!");
        location.reload();
    }
}

function hitKnife(player, knife) {
    alert("GAME OVER - SR. EGGOU HA ESTAT CUINAT");
    location.reload();
}